import java.lang.reflect.*;

public class ReflectionDemo {
    public static void main(String[] args) throws Exception {
        Class<?> cls = Class.forName("Sample");

        System.out.println("Methods:");
        for (Method m : cls.getDeclaredMethods()) {
            System.out.println("- " + m.getName());
        }

        Object obj = cls.getDeclaredConstructor().newInstance();
        Method method = cls.getDeclaredMethod("greet", String.class);
        method.setAccessible(true);
        method.invoke(obj, "Miss Mysterious");
    }
}

class Sample {
    private void greet(String name) {
        System.out.println("Hello from reflection, " + name);
    }
}
