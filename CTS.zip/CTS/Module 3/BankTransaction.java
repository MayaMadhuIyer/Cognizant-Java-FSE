import java.sql.*;

public class BankTransaction {
    public static void transferMoney(Connection conn, int fromId, int toId, int amount) throws SQLException {
        try {
            conn.setAutoCommit(false);

            // Debit
            try (PreparedStatement debit = conn.prepareStatement("UPDATE accounts SET balance = balance - ? WHERE id = ?")) {
                debit.setInt(1, amount);
                debit.setInt(2, fromId);
                debit.executeUpdate();
            }

            // Credit
            try (PreparedStatement credit = conn.prepareStatement("UPDATE accounts SET balance = balance + ? WHERE id = ?")) {
                credit.setInt(1, amount);
                credit.setInt(2, toId);
                credit.executeUpdate();
            }

            conn.commit();
            System.out.println("Transaction successful!");
        } catch (SQLException e) {
            conn.rollback();
            System.out.println("Transaction failed, rolled back.");
            e.printStackTrace();
        } finally {
            conn.setAutoCommit(true);
        }
    }

    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/testdb";
        String user = "root";
        String password = "yourpassword";

        try (Connection conn = DriverManager.getConnection(url, user, password)) {
            transferMoney(conn, 1, 2, 100);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
