import java.sql.*;

public class StudentDAO {
    private final Connection conn;

    public StudentDAO(Connection conn) {
        this.conn = conn;
    }

    public void insertStudent(int id, String name, int age) throws SQLException {
        String query = "INSERT INTO students (id, name, age) VALUES (?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, id);
            ps.setString(2, name);
            ps.setInt(3, age);
            ps.executeUpdate();
            System.out.println("Student inserted.");
        }
    }

    public void updateStudentAge(int id, int newAge) throws SQLException {
        String query = "UPDATE students SET age = ? WHERE id = ?";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, newAge);
            ps.setInt(2, id);
            ps.executeUpdate();
            System.out.println("Student updated.");
        }
    }

    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/testdb";
        String user = "root";
        String password = "yourpassword";

        try (Connection conn = DriverManager.getConnection(url, user, password)) {
            StudentDAO dao = new StudentDAO(conn);
            dao.insertStudent(1, "Alice", 20);
            dao.updateStudentAge(1, 21);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
