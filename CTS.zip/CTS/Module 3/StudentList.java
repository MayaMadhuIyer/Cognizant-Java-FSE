import java.util.ArrayList;
import java.util.Scanner;

public class StudentList {
    public static void main(String[] args) {
        ArrayList<String> students = new ArrayList<>();
        Scanner sc = new Scanner(System.in);
        String name;

        while (true) {
            System.out.print("Enter student name (or 'exit' to stop): ");
            name = sc.nextLine();
            if (name.equalsIgnoreCase("exit")) break;
            students.add(name);
        }

        System.out.println("Student names:");
        for (String student : students) {
            System.out.println(student);
        }
    }
}
