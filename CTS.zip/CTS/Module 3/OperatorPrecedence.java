public class OperatorPrecedence {
    public static void main(String[] args) {
        int result1 = 10 + 5 * 2;     // 10 + (5*2) = 20
        int result2 = (10 + 5) * 2;   // (10+5)*2 = 30
        int result3 = 100 / 5 + 10;   // (100/5) + 10 = 30
        int result4 = 100 / (5 + 10); // 100 / 15 = 6

        System.out.println("10 + 5 * 2 = " + result1);
        System.out.println("(10 + 5) * 2 = " + result2);
        System.out.println("100 / 5 + 10 = " + result3);
        System.out.println("100 / (5 + 10) = " + result4);
    }
}
