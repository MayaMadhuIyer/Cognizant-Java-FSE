public class DataTypesDemo {
    public static void main(String[] args) {
        int myInt = 100;
        float myFloat = 10.5f;
        double myDouble = 20.99;
        char myChar = 'A';
        boolean myBool = true;

        System.out.println("int: " + myInt);
        System.out.println("float: " + myFloat);
        System.out.println("double: " + myDouble);
        System.out.println("char: " + myChar);
        System.out.println("boolean: " + myBool);
    }
}
